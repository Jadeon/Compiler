The exe/application for this project is located:   tokenizer\tokenizer\bin\Debug

Running the .exe allows you to either enter a complete path to a program of your choice for tokenization or simply hitting enter while leaving the prompt blank will default to the prog.txt in the top directory.

Currently the output of the tokenizer will give you a tokens value, row, and index.  It will eventually return type as well however at the moment a place holder value is in use.

Also included is a sample_output.png image for viewing.

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.IO;

namespace tokenizer
{
    class Program
    {
        static void Main(string[] args)
        {     
            string[] programLines = {};
            List<Token> tokens = new List<Token>();
            string file = readFile();
            try
            {
                programLines = File.ReadAllLines(file);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            List<string> keep_delim = new List<string>();
            List<string> toss_delim = new List<string>();
            keep_delim = File.ReadAllLines(@"..\..\k_delimiter.txt").ToList();
            toss_delim = File.ReadAllLines(@"..\..\ta_delimiter.txt").ToList();
            tokens = tokenize(programLines, keep_delim, toss_delim);

            foreach (Token x in tokens) {
                Console.WriteLine("Token: {0,-10}Type: {1,-10}Row: {2,-10}Index: {3,-10}",x.value,x.type,x.row,x.index);
            }
            Console.ReadLine();            
        }

        public static string readFile()
        {
            string file = "";
            string readLine = "";

            Console.WriteLine("Enter the full path to the program you would like to tokenize:");
            Console.WriteLine("(Press Enter to use default file)");

            readLine = Console.ReadLine();
            file = String.IsNullOrWhiteSpace(readLine) ? @"..\..\..\prog.txt" : readLine;

            if (!File.Exists(file))
            {
                Console.WriteLine("File Not Found: " + file);
                Console.WriteLine("Press any key...");
                Console.ReadKey();
                Console.Clear();
                file = readFile();                
            }

            return file;
        }

        public static List<Token> tokenize(string[] program, List<string> keep_delim, List<string> toss_delim)
        {
            List<Token> tokenList = new List<Token>();
            List<string> master_delim = new List<string>(keep_delim.Union(toss_delim));
            string stringBuilder = "";            
            int row = 0;
            #region Iterate-through-Array
            foreach (string Line in program)
            {
                row++;
                int index = 0;
                #region Iterate-through-Line
                while (index < Line.Length)
                {
                    string activeToken = Line[index].ToString();
                    string nextToken = "";                
         

                    #region Delimiter-Found
                    if (master_delim.Contains(activeToken))
                    {
                        #region Empty String Builder
                        if (stringBuilder != "")
                        {
                            
                            tokenList.Add(new Token(stringBuilder, "temp", index, row));
                            stringBuilder = "";
                        }
                        #endregion

                        #region Special(")-Delimiter
                        if (activeToken == "\"")
                        {                            
                            int searchResult = Line.IndexOf('"', index + 1);
                            stringBuilder = Line.Substring(index, searchResult - index) + "\"";
                            tokenList.Add(new Token(stringBuilder, "temp", index, row));
                            stringBuilder = "";
                            index = searchResult + 1;
                        }
                        #endregion   

                        #region ThrowAway-Delimiter
                        else if (toss_delim.Contains(activeToken))
                        {
                            stringBuilder = "";
                            index++;
                        }
                        #endregion

                        #region Double-Delimiter
                        else if (index < Line.Length - 1)
                        {
                            nextToken = Line[index + 1].ToString();
                            if (keep_delim.Contains(nextToken) && (nextToken == ">" || nextToken == "=") && activeToken != "<")
                            {
                                tokenList.Add(new Token(activeToken + nextToken, "temp", index, row));
                                index += 2;
                            }

                            #region Standard-Delimiter
                            else
                            {
                                tokenList.Add(new Token(activeToken, "temp", index, row));
                                index++;
                            }
                            #endregion
                        }
                        #region Standard-Delimiter
                        else
                        {
                            tokenList.Add(new Token(activeToken, "temp", index, row));
                            index++;
                        }
                        #endregion
                        #endregion
                    }
                    #endregion

                    #region StringBuilder
                    else {
                        stringBuilder += activeToken.ToString();
                        index++;
                    }
                    #endregion
                }
                #endregion
            }
            return tokenList;
            #endregion
        }

        public static Boolean program(string token){
            Boolean retVal = false;
            if(func(token) && func_list(token)){
                retVal = true;
            }
            return (retVal);
        }

        

        public static Boolean func(string token) {
            return true;
        }

        public static Boolean func_list(string token) {
            return true;
        }
    }
}

